mkdir -p ~/.streamlit/

echo "\n[server]\nheadless = true\nenableCORS = false\nport = $PORT\n" > ~/.streamlit/config.toml